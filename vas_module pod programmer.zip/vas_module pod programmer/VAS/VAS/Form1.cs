﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VAS
{
    public partial class Form1 : Form
    {

        delegate void serialCalback(string data);
        private string incomingData;
        Serial mySerialPort;
        string temp = "";
        List<ArduinoData> dataFromArduino = new List<ArduinoData>();

        ArduinoData serialNumber;
        ArduinoData programmaDatum;
        ArduinoData configure;

        String dataStringToSend = "";


        public Form1()
        {
            InitializeComponent();
            mySerialPort = new Serial(cbxSelectCom, cbxSelectBaudRate, btnSerialRefresh,
            btnSerialConnect, btnSerialDisConnect, groupBox2, lblSerialStatus, serialPort1);
            mySerialPort.getSerialPorts();

            cbxSelectBaudRate.SelectedIndex =1;

            dataFromArduino.Add(new ArduinoData("B", textBox1));//oil timer
            dataFromArduino.Add(new ArduinoData("C", textBox2));//stoptimer
            dataFromArduino.Add(new ArduinoData("D", textBox3));//delay start
            dataFromArduino.Add(new ArduinoData("E", textBox4));//ac failure
            dataFromArduino.Add(new ArduinoData("F", textBox5));//auto stop
            dataFromArduino.Add(new ArduinoData("G", textBox6));//test start
            dataFromArduino.Add(new ArduinoData("I", textBox8));//configure 2
            dataFromArduino.Add(new ArduinoData("J", textBox9));//exp. reset
            dataFromArduino.Add(new ArduinoData("K", textBox10));//exp. muteable
            dataFromArduino.Add(new ArduinoData("L", textBox11));//exp. alarm
            dataFromArduino.Add(new ArduinoData("M", textBox12));//exp. inhibit
            dataFromArduino.Add(new ArduinoData("N", textBox13));//exp. shutdown
            dataFromArduino.Add(new ArduinoData("O", textBox14));//exp. in polar
            dataFromArduino.Add(new ArduinoData("P", textBox15));//exp. relay
            dataFromArduino.Add(new ArduinoData("Q", textBox16));//exp. first
            dataFromArduino.Add(new ArduinoData("T", textBox19));//aantal starts
            dataFromArduino.Add(new ArduinoData("U", textBox20));//aantal minuten diesel in bedrijf
            dataFromArduino.Add(new ArduinoData("V", textBox21));//aantal minuten kast in bedrijf
            dataFromArduino.Add(new ArduinoData("W", textBox22));//hoogste batterijspanning
            dataFromArduino.Add(new ArduinoData("X", textBox23));//laagste batterijspanning
            dataFromArduino.Add(new ArduinoData("Y", textBox24));//
            dataFromArduino.Add(new ArduinoData("Z", textBox25));//

            serialNumber= new ArduinoData("S", textBox18);
            programmaDatum = new ArduinoData("R", textBox17);
            configure = new ArduinoData("H", comboBox1);



        }


        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void btnSerialRefresh_Click_1(object sender, EventArgs e)
        {
            mySerialPort.getSerialPorts();
            
        }

        private void btnSerialDisConnect_Click_1(object sender, EventArgs e)
        {
            mySerialPort.closeConnection();
            groupBox2.Enabled = false;
            groupBox4.Enabled = false;
            timer1.Enabled = false;
        }

        private void btnSerialConnect_Click_1(object sender, EventArgs e)
        {
            mySerialPort.makeConnestion();
            if (mySerialPort.connected)
            {
                groupBox2.Enabled = true;
                groupBox4.Enabled = true;
                
                sendSerialdata("GET@#\n");
            }    
        }
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {         
            incomingData = serialPort1.ReadExisting();  
            this.Invoke(new EventHandler(ShowData));
        }
        private void ShowData(object sender, EventArgs e)
        {
            sendText(tbxData, incomingData);
        }
        private void sendText(string data)
        {
            if (this.tbxData.InvokeRequired)
            {
                serialCalback calback = new serialCalback(sendText);
                this.Invoke(calback, new object[] { data });
            }
            else
            {
                sendText(tbxData, data);
            }
        }
        private void sendText(TextBox textBox, string text)
        {            
            char[] charsToTrim = {'\n'};
            string cleanString = text.Trim(charsToTrim);

            foreach (var item in cleanString)
            {                
                if (item == '#')
                {
                    checkData(temp);
                    temp = "";
                }
                else
                {
                    temp += item;                  
                }
                
            }

        }
        private void checkData(String data)
        {
            string[] subs = data.Split('@');

                foreach (var item in dataFromArduino)
                {
                    if (item.checkName(subs[0]))
                    {     
                        item.tbxData.Text = subs[1];
                        item.value = item.tbxData.Text;

                        Console.WriteLine(item.value);
                        Console.WriteLine(item.tbxData.Text);
                        break;                        
                    }  
                }
            if (String.Compare("H", subs[0]) == 0)
            {
                int value = int.Parse(subs[1]);
                if (value == 0 || value == 1)
                    comboBox1.SelectedIndex = value;
               // else
                //    comboBox1.SelectedIndex = 3;
            }

                // comboBox1.SelectedIndex = int.Parse(subs[1]);                
            else if (String.Compare("S", subs[0]) == 0)
            {
                serialNumber.setValue(subs[1]);
            }

            else if (String.Compare("R", subs[0]) == 0)
            {
                programmaDatum.setValue(subs[1]);
            }               
                    

            foreach (var sub in subs)
            {
                Console.WriteLine(sub);
            }
        }
        private void sendSerialdata(string data)
        {
            try
            {
                serialPort1.Write(data);
                serialPort1.Write("\n");
                sendMessage(tbxData, "OK");
             
            }
            catch (TimeoutException)
            {
                sendMessage(tbxData, "Sending error");
            }
        }
        private void sendMessage(TextBox tbx, String message)
        {
            tbx.AppendText(message);
            tbx.AppendText(Environment.NewLine);

        }
        private void btn_getData_Click(object sender, EventArgs e)
        {
            sendSerialdata("GET@#\n");
            timer1.Enabled = true;
        }

        private void btn_sendData_Click(object sender, EventArgs e)
        {
            if (checCorrectData())
            {               
                makeDataString();
                sendSerialdata(dataStringToSend);
            } 
        }
        private bool checCorrectData()
        {          
            for (int i = 0; i < dataFromArduino.Count(); i++)
            {
                if (dataFromArduino[i].tbxData.Enabled)
                    if (!checCorrectData(i))
                        return false;
            }     
            if(configure.cBox.SelectedIndex == -1)
            {                
                return false;
            }                
            return true;
        }
        private bool checCorrectData(int numer)
        {
            bool dataCorrect = true;
            bool result = int.TryParse(dataFromArduino[numer].tbxData.Text, out int value);

            if(!result ||  value <0 || value > 255)
            {
                dataFromArduino[numer].tbxData.BackColor = Color.LightSalmon;
                dataCorrect = false;
            }                
            else
            {
                if(dataFromArduino[numer].tbxData.BackColor == Color.LightSalmon)
                    dataFromArduino[numer].tbxData.BackColor = Color.White;
                dataFromArduino[numer].value = dataFromArduino[numer].tbxData.Text;
            }
            return dataCorrect;
        }
        void makeDataString()
        {
            dataStringToSend = "SET@";
            foreach (var item in dataFromArduino)
            {
                if(item.tbxData.Enabled)
                    makeWord(item);
            }
            
            makeWord(serialNumber);
            makeWord(programmaDatum);

            dataStringToSend += configure.name;
            dataStringToSend += "/";
            dataStringToSend += configure.cBox.SelectedItem;
            dataStringToSend += "#";
            Console.WriteLine(dataStringToSend);

        }
        void makeWord(ArduinoData item)
        {
            if (item.tbxData.Enabled)
            {
                dataStringToSend += item.name;
                dataStringToSend += "/";
                dataStringToSend += item.value;
                dataStringToSend += "@";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
          
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            checCorrectData(0);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            checCorrectData(1);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            checCorrectData(2);
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            checCorrectData(3);
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            checCorrectData(4);
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            checCorrectData(5);
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            checCorrectData(6);
        }
    }
}
