﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VAS
{
    class ArduinoData
    {
        public TextBox tbxData { get; set; }
        public String name { get; set; }
        public String value { get; set; }
        public ComboBox cBox { get; set; }

        public ArduinoData(String name, TextBox tbxData)
        {
            this.name = name;
            this.value = "0";
            this.tbxData = tbxData;
        }
        public ArduinoData(String name, ComboBox cBox)
        {
            this.name = name;
            this.value = "0";
            this.cBox = cBox;
            this.cBox.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cBox.SelectedIndex = 0;
        }


        public bool checkName(String incomingName)
        {
            if (String.Compare(name, incomingName) == 0)
                return true;
            else
                return false;
        }
        public void setValue(String data)
        {
            this.tbxData.Text = data;
            this.value = this.tbxData.Text;
        }
    }
}
